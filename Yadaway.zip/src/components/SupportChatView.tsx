import React, { useState, useEffect, useRef } from 'react';
import { 
  Headphones, 
  Send, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  MessageSquare, 
  Truck, 
  Package, 
  User, 
  Store, 
  HelpCircle,
  FileText,
  RefreshCw,
  PhoneCall,
  Info
} from 'lucide-react';
import { UserProfile } from '../types';
import { YadawyLogo } from './YadawyLogo';

export interface SupportChatMessage {
  id: string;
  sender: 'user' | 'support';
  senderRole?: 'customer' | 'artisan';
  text: string;
  timestamp: string;
  isQuickAction?: boolean;
}

interface SupportChatViewProps {
  currentUser: UserProfile | null;
  onNavigateHome: () => void;
  onNavigateDashboard: () => void;
  onNavigateTracking: () => void;
  onOpenAuth: () => void;
}

const COMMON_QUESTIONS = [
  {
    role: 'customer',
    q: 'متى يصل طلبي وموعد التسليم؟',
    ans: 'تتولى شركة الشحن الرسمية توصيل الطلبات خلال 3 إلى 5 أيام عمل من استلامها من ورشة الصانع. يمكنك متابعة حالة طلبك برقم الشحنة مباشرة عبر صفحة التتبع.'
  },
  {
    role: 'customer',
    q: 'ما هو الضمان وطريقة المعاينة عند الاستلام؟',
    ans: 'معاملتك محمية بضمان يدوي 100%. يحق لك فحص ومعاينة القطعة اليدوية بحضور مندوب شركة الشحن قبل سداد المبلغ في حالة الدفع عند الاستلام.'
  },
  {
    role: 'artisan',
    q: 'كيف أقوم بتسليم الطلبات الجاهزة لشركة الشحن؟',
    ans: 'بمجرد انتهائك من تجهيز القطعة وتغليفها، اضغط على زر "تسليم لمندوب شركة الشحن" في لوحة الصانع، وسيصلك مندوبنا لاستلام الطرد مع إيصال رسمي.'
  },
  {
    role: 'artisan',
    q: 'متى يتم تحويل مستحقات ومبيعات الورشة؟',
    ans: 'يتم تحويل الأرباح المستحقة لورشتك أسبوعياً فور تأكيد استلام العميل للطلب عبر إنستاباي أو فودافون كاش أو تحويل بنكي حسب بياناتك المسجلة.'
  },
  {
    role: 'all',
    q: 'كيف أطلب تعديل أو تفصيل قطعة خاصة؟',
    ans: 'يمكنك الضغط على "طلب تفصيل وتعديل خاص" في صفحة المنتج أو متجر الصانع. وسيقوم فريق الدعم بمراجعة المواصفات وإرسالها للورشة لتقدير التكلفة والوقت.'
  }
];

export const SupportChatView: React.FC<SupportChatViewProps> = ({
  currentUser,
  onNavigateHome,
  onNavigateDashboard,
  onNavigateTracking,
  onOpenAuth,
}) => {
  // Determine if user is artisan or customer
  const [activeUserType, setActiveUserType] = useState<'customer' | 'artisan'>(() => {
    return currentUser?.role === 'artisan' ? 'artisan' : 'customer';
  });

  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial messages based on user type
  const [messages, setMessages] = useState<SupportChatMessage[]>(() => {
    const saved = localStorage.getItem('yadawy_support_messages');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // ignore
      }
    }
    return [
      {
        id: 'msg-welcome-1',
        sender: 'support',
        text: `أهلاً بك في خدمة عملاء ودعم منصة "يَدَوِي" الرسمية! 🌿
أنا هنا معك على مدار 24 ساعة، 7 أيام في الأسبوع.
أنا حلقة الوصل المباشرة والمخصصة لخدمة المتسوقين، والعملاء، وأصحاب الورش والحرفيين لمتابعة وتيسير كل خطوات الشحن، التصنيع، والطلبات وحل أي مشكلة فوراً.`,
        timestamp: 'الآن'
      },
      {
        id: 'msg-welcome-2',
        sender: 'support',
        text: 'يسعدني الرد على أي استفسار حول: تتبع شحنتك، تفاصيل استلام وتوصيل الطلبات، تعديل المشغولات اليدوية، أو مساعدة الورش في استلام المندوب للمنتجات.',
        timestamp: 'الآن'
      }
    ];
  });

  // Save messages to local storage
  useEffect(() => {
    localStorage.setItem('yadawy_support_messages', JSON.stringify(messages));
  }, [messages]);

  // Scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = (textToSend?: string) => {
    const messageContent = (textToSend || inputMessage).trim();
    if (!messageContent) return;

    const userMsg: SupportChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      senderRole: activeUserType,
      text: messageContent,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputMessage('');

    // Simulate 24/7 Support Agent Smart Assistant Response
    setIsTyping(true);
    setTimeout(() => {
      let replyText = '';
      const lower = messageContent.toLowerCase();

      if (lower.includes('شحن') || lower.includes('توصيل') || lower.includes('مندوب') || lower.includes('تتبع')) {
        replyText = `شكراً لتواصلك يا فندم بخصوص الشحن.
شركة الشحن المعتمدة تتولى استلام المشغولة اليدوية من الورشة بعد انتهاء الصانع من إعدادها.
تصل الشحنة عادة خلال 3 إلى 5 أيام عمل، وستصلك رسالة قبل وصول المندوب بنصف ساعة.
إذا كان لديك رقم طلب (مثل YD-8914)، اكتبه لي وسأتحقق لك من خط سيره فوراً!`;
      } else if (lower.includes('فلوس') || lower.includes('دفع') || lower.includes('استرجاع') || lower.includes('كاش') || lower.includes('إنستاباي')) {
        replyText = `حقوقك المالية محفوظة بضمان منصة يدوي 100%.
- إذا كنت مشترياً: يتم الدفع عند الاستلام بعد المعاينة أو عبر قنوات الدفع الإلكترونية الآمنة.
- إذا كنت صانعاً: يتم تحويل مستحقاتك وأرباحك كل أسبوع عبر إنستاباي أو فودافون كاش أو حسابك البنكي المعتمد فور تسليم الطلب للعميل.`;
      } else if (lower.includes('صانع') || lower.includes('ورشة') || lower.includes('بائع') || lower.includes('حرفي')) {
        replyText = `أهلاً بفناني ومبدعي مصر! 
بصفتنا حلقة الوصل الإدارية واللوجستية، نتابع تجهيز قطعكم اليدوية وتنسيق وصول المندوب لاستلامها، دون الحاجة لتحمل عناء الشحن أو التحصيل. نحن نتكفل بالعملية كاملة حتى وصول المبلغ لحسابكم.`;
      } else if (lower.includes('مشكلة') || lower.includes('كسر') || lower.includes('تالف') || lower.includes('شكوى')) {
        replyText = `نعتذر جداً عن أي إزعاج! بصفتنا المشرف والضامن للشحنات:
يرجى إرسال رقم الطلب واسمك، وسيقوم فريق الدعم الفوري بتوجيه مندوب شركة الشحن لاستبدال القطعة أو استرجاع المبلغ فوراً دون أي مصاريف شحن إضافية عليك.`;
      } else {
        replyText = `تم استلام رسالتك باهتمام من قِبل إدارة منصة يدوي. 
نحن متواجدون معك 24 ساعة لخدمة العملاء وأصحاب الورش وحل جميع التحديات بين العميل وشركة الشحن والورشة. 
سواء كنت تحتاج لتعديل عنوان الشحن، الاستفسار عن مقاسات، أو متابعة إنتاج ورشتك، سنقوم بالإجراء اللازم على الفور.`;
      }

      const botMsg: SupportChatMessage = {
        id: `support-${Date.now()}`,
        sender: 'support',
        text: replyText,
        timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 900);
  };

  const handleQuickQuestion = (q: string, ans: string) => {
    handleSendMessage(q);
  };

  const handleResetChat = () => {
    if (window.confirm('هل تريد إعادة تعيين المحادثة وبدء جلسة جديدة مع الدعم؟')) {
      localStorage.removeItem('yadawy_support_messages');
      setMessages([
        {
          id: 'msg-welcome-reset',
          sender: 'support',
          text: 'أهلاً بك مجدداً في شات خدمة عملاء ودعم منصة يدوي (24/7). كيف أستطيع مساعدتك الآن؟',
          timestamp: 'الآن'
        }
      ]);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] py-6 sm:py-10 px-4 sm:px-6 text-right">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Top Header Card */}
        <div className="p-6 rounded-3xl bg-[#254D3F] text-white shadow-xl relative overflow-hidden border border-[#1A372D]">
          {/* Subtle background glow/pattern */}
          <div className="absolute -left-10 -bottom-10 w-48 h-48 rounded-full bg-white/5 blur-2xl pointer-events-none" />
          <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-[#C97A57]/20 blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center shrink-0 shadow-inner">
                <Headphones className="w-7 h-7 text-[#E6E1D3]" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <h1 className="font-display font-black text-xl sm:text-2xl text-white">
                    شات الدعم وخدمة العملاء 24 ساعة
                  </h1>
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    متصل الآن (24/7)
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-[#C5D3CE] max-w-xl leading-relaxed">
                  حلقة الوصل الرسمية المباشرة بين العملاء، وأصحاب الورش والحرفيين، وشركة الشحن. متواجدون على مدار الساعة لحل كافة استفساراتك ومشاكلك فوراً.
                </p>
              </div>
            </div>

            {/* Quick Actions in Header */}
            <div className="flex items-center gap-2 w-full md:w-auto">
              <button
                onClick={handleResetChat}
                title="إعادة بدء المحادثة"
                className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                aria-label="إعادة بدء المحادثة"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
              <button
                onClick={onNavigateTracking}
                className="flex-1 md:flex-none px-3.5 py-2 rounded-xl bg-[#C97A57] hover:bg-[#B36846] text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Truck className="w-3.5 h-3.5" />
                <span>تتبع شحنة</span>
              </button>
            </div>
          </div>

          {/* User Mode Selector: Are you inquiring as a Customer or an Artisan? */}
          <div className="mt-5 pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-[#C5D3CE] font-bold text-[11px]">أنا أتواصل بصفتي:</span>
              <div className="flex p-1 rounded-xl bg-black/20 border border-white/10">
                <button
                  type="button"
                  onClick={() => setActiveUserType('customer')}
                  className={`px-3 py-1 rounded-lg font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeUserType === 'customer'
                      ? 'bg-white text-[#254D3F] shadow-xs'
                      : 'text-[#C5D3CE] hover:text-white'
                  }`}
                >
                  <User className="w-3 h-3" />
                  <span>عميل / مشتري</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveUserType('artisan')}
                  className={`px-3 py-1 rounded-lg font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeUserType === 'artisan'
                      ? 'bg-[#C97A57] text-white shadow-xs'
                      : 'text-[#C5D3CE] hover:text-white'
                  }`}
                >
                  <Store className="w-3 h-3" />
                  <span>صانع / صاحب ورشة</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-3 text-[11px] text-[#A3B8B0]">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                ضمان يدوي المعتمد
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#C97A57]" />
                استجابة فورية 24/7
              </span>
            </div>
          </div>
        </div>

        {/* Chat Container */}
        <div className="bg-white rounded-3xl border border-[#E6E1D3] shadow-md overflow-hidden flex flex-col h-[560px]">
          
          {/* Chat Window Banner */}
          <div className="bg-[#F6F4ED] px-5 py-3 border-b border-[#E6E1D3] flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-[#1F2937] font-bold">
              <MessageSquare className="w-4 h-4 text-[#254D3F]" />
              <span>محادثة دعم خاصة ومحمية</span>
            </div>
            <div className="text-[11px] text-[#6B7280]">
              {currentUser ? `مسجل كـ: ${currentUser.name}` : 'تتواصل كزائر (يمكنك حفظ سجل محادثتك)'}
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-[#FDFBF7]/60">
            {messages.map((msg) => {
              const isSupport = msg.sender === 'support';
              return (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2.5 ${isSupport ? 'justify-start' : 'justify-end'}`}
                >
                  {/* Support Avatar */}
                  {isSupport && (
                    <div className="w-8 h-8 rounded-full bg-[#254D3F] text-white flex items-center justify-center shrink-0 text-xs font-bold shadow-xs">
                      <Headphones className="w-4 h-4" />
                    </div>
                  )}

                  {/* Message Bubble */}
                  <div
                    className={`max-w-[82%] sm:max-w-[70%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                      isSupport
                        ? 'bg-white text-[#1F2937] border border-[#E6E1D3] rounded-br-none shadow-xs'
                        : 'bg-[#254D3F] text-white rounded-bl-none shadow-xs'
                    }`}
                  >
                    <div className="whitespace-pre-line font-body">{msg.text}</div>
                    <div
                      className={`text-[10px] mt-1.5 flex items-center gap-1 ${
                        isSupport ? 'text-[#9CA3AF]' : 'text-emerald-200'
                      }`}
                    >
                      <span>{msg.timestamp}</span>
                      {isSupport && <span>• خدمة عملاء يدوي</span>}
                      {!isSupport && (
                        <span>
                          • {msg.senderRole === 'artisan' ? 'صانع' : 'عميل'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* User Avatar */}
                  {!isSupport && (
                    <div className="w-8 h-8 rounded-full bg-[#C97A57] text-white flex items-center justify-center shrink-0 text-xs font-bold shadow-xs">
                      {msg.senderRole === 'artisan' ? <Store className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>
                  )}
                </div>
              );
            })}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                <div className="w-7 h-7 rounded-full bg-[#254D3F] text-white flex items-center justify-center shrink-0">
                  <Headphones className="w-3.5 h-3.5" />
                </div>
                <div className="bg-white border border-[#E6E1D3] rounded-2xl px-4 py-2 flex items-center gap-1.5 shadow-xs">
                  <span className="text-[11px] text-[#254D3F] font-bold">فريق الدعم يكتب الرد...</span>
                  <span className="w-1.5 h-1.5 bg-[#254D3F] rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-[#254D3F] rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-[#254D3F] rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick FAQ Chips */}
          <div className="px-4 py-2.5 bg-[#F6F4ED] border-t border-[#E6E1D3] overflow-x-auto flex items-center gap-2 no-scrollbar">
            <span className="text-[10px] font-bold text-[#6B7280] shrink-0 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#C97A57]" />
              استفسارات سريعة:
            </span>
            {COMMON_QUESTIONS.filter(q => q.role === 'all' || q.role === activeUserType).map((faq, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleQuickQuestion(faq.q, faq.ans)}
                className="shrink-0 px-3 py-1 rounded-full bg-white border border-[#D5CEBD] text-[#254D3F] hover:bg-[#254D3F] hover:text-white text-[11px] font-bold transition-colors cursor-pointer"
              >
                {faq.q}
              </button>
            ))}
          </div>

          {/* Message Input Area */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 sm:p-4 bg-white border-t border-[#E6E1D3] flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder={
                activeUserType === 'artisan'
                  ? 'اكتب استفسارك بخصوص استلام المندوب، مستحقات الورشة، أو طلباتك...'
                  : 'اكتب استفسارك بخصوص طلبك، مواعيد الشحن، أو أي مساعدة تحتاجها...'
              }
              className="flex-1 px-4 py-3 rounded-2xl bg-[#F6F4ED] border border-[#E6E1D3] text-xs sm:text-sm text-[#1F2937] placeholder-[#9CA3AF] focus:outline-none focus:border-[#254D3F] focus:bg-white transition-all"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim() || isTyping}
              className="px-5 py-3 rounded-2xl bg-[#254D3F] hover:bg-[#1A372D] disabled:opacity-40 text-white font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-md cursor-pointer shrink-0"
            >
              <span>إرسال</span>
              <Send className="w-4 h-4 rotate-180" />
            </button>
          </form>

        </div>

        {/* Bottom Informational Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-white border border-[#E6E1D3] flex items-start gap-3 shadow-xs">
            <div className="p-2.5 rounded-xl bg-[#254D3F]/10 text-[#254D3F] shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-[#1F2937] mb-1">دعم شات 24 ساعة</h4>
              <p className="text-[11px] text-[#6B7280] leading-relaxed">
                متاحون طوال اليوم لحل مشكلات الطلبات، تأخير الشحن، وتنسيق التوصيل بين الجميع.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-[#E6E1D3] flex items-start gap-3 shadow-xs">
            <div className="p-2.5 rounded-xl bg-[#C97A57]/15 text-[#C97A57] shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-[#1F2937] mb-1">تنسيق الشحن والمناديب</h4>
              <p className="text-[11px] text-[#6B7280] leading-relaxed">
                حلقة وصل لوجستية رسمية مع شركة الشحن المعتمدة دون الحاجة للتواصل الخارجي.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-[#E6E1D3] flex items-start gap-3 shadow-xs">
            <div className="p-2.5 rounded-xl bg-emerald-100 text-emerald-800 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-[#1F2937] mb-1">حماية وضمان يدوي</h4>
              <p className="text-[11px] text-[#6B7280] leading-relaxed">
                معاينة المنتجات عند الاستلام وضمان تحصيل مستحقات الورش بأمان واحترافية.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
