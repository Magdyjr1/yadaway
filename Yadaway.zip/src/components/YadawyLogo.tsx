import React from 'react';

export interface YadawyLogoProps {
  /**
   * Layout variant:
   * - 'horizontal': Emblem alongside text (ideal for Navbar and headers)
   * - 'vertical': Stacked emblem on top of text (identical to the uploaded brand image)
   * - 'mark': Just the iconic Egyptian Hand & Terracotta Pottery symbol
   * - 'compact': Smaller footprint for mobile headers
   */
  variant?: 'horizontal' | 'vertical' | 'mark' | 'compact';
  /**
   * Theme mode:
   * - 'light': Dark green & terracotta on light/cream backgrounds (default)
   * - 'dark': Light cream & terracotta on dark backgrounds (e.g. in Footer)
   */
  theme?: 'light' | 'dark';
  /**
   * Size multiplier or height indicator
   */
  size?: 'sm' | 'md' | 'lg' | 'xl';
  /**
   * Show or hide the tagline ("سوق الحرف والفنون المصرية")
   */
  showTagline?: boolean;
  /**
   * Optional custom CSS class
   */
  className?: string;
  /**
   * Custom subtitle override (defaults to "سوق الحرف والفنون المصرية")
   */
  subtitle?: string;
}

/**
 * High-definition vector emblem of the official YADAWY (يدوي) identity:
 * - Geometric Egyptian Hand (كف خمسة وخميسة)
 * - Ornate Terracotta Arabesque Filigree (زخارف أرابيسك تراثية)
 * - Handcrafted Clay Water Jug / Pottery (جرة فخارية مصرية أصيلة)
 */
export const YadawyEmblem: React.FC<{
  size?: number;
  isDark?: boolean;
  className?: string;
}> = ({ size = 48, isDark = false, className = '' }) => {
  const greenStroke = isDark ? '#E6E1D3' : '#1E3F32';
  const greenFill = isDark ? '#2A5546' : '#254D3F';
  const terracotta = '#C97A57';
  const terracottaDark = '#A8522E';
  const creamLight = isDark ? '#1F3E32' : '#F6F4ED';

  return (
    <svg
      width={size}
      height={size * 1.125}
      viewBox="0 0 160 180"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 transition-transform ${className}`}
      aria-label="شعار يدوي - كف الحرف المصرية والفخار الأصيل"
    >
      {/* Defs for gradients & filters */}
      <defs>
        <linearGradient id="terracottaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#DE8965" />
          <stop offset="100%" stopColor="#A8522E" />
        </linearGradient>
        <linearGradient id="potteryHighlight" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#B35B35" />
          <stop offset="35%" stopColor="#E09270" />
          <stop offset="70%" stopColor="#C97A57" />
          <stop offset="100%" stopColor="#8E3C1B" />
        </linearGradient>
      </defs>

      {/* 1. GEOMETRIC HAND (الكف الأخضر العتيق) */}
      <g stroke={greenStroke} strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="miter">
        {/* Central Long Finger (الأصبع الأوسط - الأطول مع قمة مثلثة) */}
        <path d="M 72,55 L 72,18 L 80,8 L 88,18 L 88,55" fill="none" />

        {/* Index Finger (الأصبع الأيمن / السبابة) */}
        <path d="M 88,55 L 94,55 L 94,28 L 102,18 L 108,28 L 108,60" fill="none" />

        {/* Ring Finger (الأصبع الأيسر / الوسطى الأخرى) */}
        <path d="M 72,55 L 66,55 L 66,28 L 58,18 L 52,28 L 52,60" fill="none" />

        {/* Thumb & Little Finger Wing Right (الإبهام / الخنصر الأيمن المتدرج للخارج) */}
        <path
          d="M 108,60 L 114,60 L 114,50 L 122,58 L 132,68 L 118,84 L 112,82"
          fill="none"
        />

        {/* Thumb & Little Finger Wing Left (الإبهام / الخنصر الأيسر المتدرج للخارج) */}
        <path
          d="M 52,60 L 46,60 L 46,50 L 38,58 L 28,68 L 42,84 L 48,82"
          fill="none"
        />

        {/* Outer Palm Contour descending towards base / wrist */}
        <path
          d="M 28,68 L 42,84 L 48,82 L 50,118 L 80,140 L 110,118 L 112,82 L 118,84 L 132,68"
          fill="none"
        />

        {/* Wrist Base Chevron */}
        <path d="M 50,118 L 80,140 L 110,118" fill="none" strokeWidth="6" />
      </g>

      {/* 2. INNER ARABESQUE / ISLAMIC FILIGREE (الزخارف النباتية والأرابيسك التيراكوتا) */}
      <g stroke={terracotta} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none">
        {/* Top Arch Crown */}
        <path d="M 64,68 C 68,44 76,34 80,30 C 84,34 92,44 96,68" />
        
        {/* Inner Floral Palmettes (تفريعات لولبية شرقية متناظرة) */}
        <path d="M 80,30 Q 80,48 70,54 Q 60,60 52,74" />
        <path d="M 80,30 Q 80,48 90,54 Q 100,60 108,74" />

        {/* Middle Foliage Spirals */}
        <path d="M 64,52 C 54,58 48,68 56,76 C 64,84 72,78 72,70 C 72,62 66,58 60,64" />
        <path d="M 96,52 C 106,58 112,68 104,76 C 96,84 88,78 88,70 C 88,62 94,58 100,64" />

        {/* Symmetrical Arabesque Crest above Jug */}
        <path d="M 80,46 C 76,56 70,64 64,68 C 60,70 56,74 58,80 C 60,86 68,88 74,82" />
        <path d="M 80,46 C 84,56 90,64 96,68 C 100,70 104,74 102,80 C 100,86 92,88 86,82" />

        {/* Connecting Heart Leaf */}
        <path d="M 74,82 Q 80,72 86,82" />
        <path d="M 80,62 L 80,82" strokeWidth="2.5" />
      </g>

      {/* 3. TERRACOTTA POTTERY VESSEL / CLAY JUG (الجرة الفخارية المصرية) */}
      <g>
        {/* Jug Base Shadow / Cushion */}
        <ellipse cx="80" cy="144" rx="14" ry="3.5" fill={isDark ? '#0F1E18' : '#DED7C8'} />

        {/* Jug Body and Neck */}
        <path
          d="
            M 73,88 
            L 87,88 
            C 86,92 84,95 85,98 
            C 89,102 96,108 97,118 
            C 98,128 92,138 87,141 
            L 73,141 
            C 68,138 62,128 63,118 
            C 64,108 71,102 75,98 
            C 76,95 74,92 73,88 
            Z
          "
          fill="url(#potteryHighlight)"
          stroke={terracottaDark}
          strokeWidth="1.8"
        />

        {/* Flared Jug Lip / Rim */}
        <path
          d="M 71,87 C 71,85 89,85 89,87 C 89,89 71,89 71,87 Z"
          fill="#DE8965"
          stroke={terracottaDark}
          strokeWidth="1.5"
        />

        {/* Left Jug Handle (المقبض الأيسر) */}
        <path
          d="M 73,99 C 64,102 63,114 70,120 C 72,121 73,120 72,118 C 67,114 67,106 74,102 Z"
          fill="#B8623D"
        />

        {/* Right Jug Handle (المقبض الأيمن) */}
        <path
          d="M 87,99 C 96,102 97,114 90,120 C 88,121 87,120 88,118 C 93,114 93,106 86,102 Z"
          fill="#944322"
        />

        {/* Traditional Engraved Band on Pot Belly (طوق الزخرفة الفخاري) */}
        <path
          d="M 68,116 Q 80,120 92,116"
          stroke="#F6F4ED"
          strokeWidth="1.2"
          strokeDasharray="2,2"
          fill="none"
          opacity="0.85"
        />
        <path
          d="M 69,122 Q 80,126 91,122"
          stroke="#F6F4ED"
          strokeWidth="1.2"
          strokeDasharray="2,2"
          fill="none"
          opacity="0.85"
        />
      </g>
    </svg>
  );
};

/**
 * Complete Official Brand Identity Component for YADAWY (يدوي)
 */
export const YadawyLogo: React.FC<YadawyLogoProps> = ({
  variant = 'horizontal',
  theme = 'light',
  size = 'md',
  showTagline = true,
  className = '',
  subtitle = 'سوق الحرف والفنون المصرية'
}) => {
  const isDark = theme === 'dark';

  // Desktop Emblem Sizes (kept fixed and unchanged for laptop & desktop)
  const desktopEmblemSizes = {
    sm: 34,
    md: 44,
    lg: 58,
    xl: 84
  };

  // Responsive sizing classes: slightly smaller on mobile screens (<sm), fixed on desktop/laptop (sm:)
  const responsiveEmblemClasses = {
    sm: 'w-6 h-[27px] sm:w-[34px] sm:h-[38.25px]',
    md: 'w-7 h-[31.5px] sm:w-[44px] sm:h-[49.5px]',
    lg: 'w-10 h-[45px] sm:w-[58px] sm:h-[65.25px]',
    xl: 'w-14 h-[63px] sm:w-[84px] sm:h-[94.5px]'
  };

  const responsiveTextClasses = {
    sm: 'text-base sm:text-lg',
    md: 'text-xl sm:text-3xl',
    lg: 'text-2xl sm:text-4xl',
    xl: 'text-3xl sm:text-5xl'
  };

  const currentEmblemSize = desktopEmblemSizes[size] || 44;
  const currentEmblemClass = responsiveEmblemClasses[size] || responsiveEmblemClasses.md;
  const currentTextClass = responsiveTextClasses[size] || responsiveTextClasses.md;

  // Colors
  const textColor = isDark ? 'text-[#F6F4ED]' : 'text-[#1E3F32]';
  const subtitleColor = isDark ? 'text-[#A3B8B0]' : 'text-[#5C6F67]';

  // 1. Mark Only Variant
  if (variant === 'mark') {
    return (
      <div className={`inline-flex items-center justify-center ${className}`}>
        <YadawyEmblem size={currentEmblemSize} isDark={isDark} className={currentEmblemClass} />
      </div>
    );
  }

  // 2. Vertical / Full Stacked Variant (Without English word)
  if (variant === 'vertical') {
    return (
      <div className={`flex flex-col items-center text-center ${className}`} dir="rtl">
        {/* Emblem on top */}
        <div className="mb-2 sm:mb-2.5 transform hover:scale-105 transition-transform">
          <YadawyEmblem 
            size={currentEmblemSize * 1.3} 
            isDark={isDark} 
            className="w-12 h-[54px] sm:w-[57px] sm:h-[64px]"
          />
        </div>

        {/* Arabic Brandmark with authentic diacritics */}
        <div className="flex items-center justify-center gap-1">
          <span className={`font-display font-black text-2xl sm:text-4xl tracking-tight ${textColor} leading-none`}>
            يَدَوِي
          </span>
        </div>

        {/* Subtitle / Tagline */}
        {showTagline && (
          <p className={`text-xs sm:text-sm font-medium mt-1.5 ${subtitleColor}`}>
            {subtitle}
          </p>
        )}
      </div>
    );
  }

  // 3. Compact Variant (for Mobile Nav, Without English word)
  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-1.5 sm:gap-2 text-right ${className}`} dir="rtl">
        <YadawyEmblem size={32} isDark={isDark} className="w-6 h-[27px] sm:w-8 sm:h-9" />
        <div className="flex flex-col">
          <span className={`font-display font-black text-lg sm:text-xl leading-tight ${textColor}`}>
            يَدَوِي
          </span>
          {showTagline && (
            <span className={`text-[10px] ${subtitleColor} truncate max-w-[140px]`}>
              {subtitle}
            </span>
          )}
        </div>
      </div>
    );
  }

  // 4. Default Horizontal Variant (for Main Navbar & Standard Headers - Without English word)
  return (
    <div className={`flex items-center gap-1.5 sm:gap-3 text-right group ${className}`} dir="rtl">
      {/* Visual Emblem Symbol (Smaller on mobile, fixed on desktop) */}
      <div className="transform group-hover:scale-105 transition-transform shrink-0">
        <YadawyEmblem size={currentEmblemSize} isDark={isDark} className={currentEmblemClass} />
      </div>

      {/* Typography Column */}
      <div className="flex flex-col justify-center">
        {/* Main Arabic Calligraphic Wordmark */}
        <span className={`font-display font-black ${currentTextClass} tracking-tight leading-none ${textColor}`}>
          يَدَوِي
        </span>

        {/* Subtitle requested by user: "سوق الحرف والفنون المصرية" */}
        {showTagline && (
          <span className={`text-[11px] sm:text-xs ${subtitleColor} font-medium mt-0.5 hidden sm:inline-block leading-tight`}>
            {subtitle}
          </span>
        )}
      </div>
    </div>
  );
};
