import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  Phone, 
  MapPin, 
  Eye, 
  EyeOff, 
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { UserProfile, UserRole, DEFAULT_USER_AVATAR } from '../types';
import { YadawyEmblem } from './YadawyLogo';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  initialMode?: 'login' | 'register';
  initialRole?: UserRole;
}

const EGYPT_GOVERNORATES = [
  'القاهرة',
  'الجيزة',
  'الإسكندرية',
  'الفيوم (قرية تونس)',
  'مطروح (سيوة)',
  'القليوبية',
  'الشرقية',
  'الدقهلية',
  'البحيرة',
  'المنوفية',
  'الغربية',
  'كفر الشيخ',
  'دمياط',
  'بورسعيد',
  'الإسماعيلية',
  'السويس',
  'بني سويف',
  'المنيا',
  'أسيوط',
  'سوهاج (أخميم)',
  'قنا',
  'الأقصر',
  'أسوان',
  'البحر الأحمر',
  'الوادي الجديد',
  'شمال سيناء',
  'جنوب سيناء'
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  initialMode = 'login'
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [governorate, setGovernorate] = useState('القاهرة');

  if (!isOpen) return null;

  // Handle Google OAuth (Direct 1-click standard sign in)
  const handleGoogleSignIn = () => {
    setIsLoading(true);
    setErrorMessage('');

    setTimeout(() => {
      setIsLoading(false);

      const googleUser: UserProfile = {
        id: 'usr-google-' + Date.now(),
        name: 'مجدي ندا',
        email: 'magdynada22223@gmail.com',
        phone: '01012345678',
        role: 'customer',
        avatar: DEFAULT_USER_AVATAR,
        provider: 'google',
        governorate: 'القاهرة',
        isVerified: true,
        createdAt: new Date().toISOString()
      };

      onLoginSuccess(googleUser);
      onClose();
    }, 500);
  };

  // Handle Form Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (mode === 'register' && !name.trim()) {
      setErrorMessage('يرجى كتابة الاسم بالكامل');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('يرجى إدخال بريد إلكتروني صالح');
      return;
    }
    if (password.length < 6) {
      setErrorMessage('كلمة المرور يجب أن لا تقل عن 6 أحرف');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);

      const newUser: UserProfile = {
        id: 'usr-' + Date.now(),
        name: name.trim() || 'مستخدم يَدَوِي',
        email: email.trim().toLowerCase(),
        phone: phone.trim() || '01012345678',
        role: 'customer',
        provider: 'email',
        governorate: governorate,
        avatar: DEFAULT_USER_AVATAR,
        isVerified: true,
        createdAt: new Date().toISOString()
      };

      onLoginSuccess(newUser);
      onClose();
    }, 450);
  };

  // Quick Demo Account for instant evaluation
  const handleQuickDemoLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const demoCustomer: UserProfile = {
        id: 'customer-sarah',
        name: 'سارة عبد الرحمن',
        email: 'sarah.shopper@gmail.com',
        phone: '01234567890',
        role: 'customer',
        governorate: 'القاهرة',
        address: 'المعادي، دجلة، شارع 206',
        avatar: DEFAULT_USER_AVATAR,
        provider: 'email',
        isVerified: true,
        createdAt: '2024-02-10'
      };
      onLoginSuccess(demoCustomer);
      onClose();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn text-right">
      <div 
        className="relative w-full max-w-lg bg-[#F6F4ED] rounded-3xl border border-[#E6E1D3] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-[#254D3F] text-white p-5 px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <YadawyEmblem size={36} isDark={true} />
            <div>
              <h2 className="font-display font-bold text-lg text-white">
                {mode === 'login' ? 'مرحباً بك في يَدَوِي' : 'إنشاء حساب جديد في يَدَوِي'}
              </h2>
              <p className="text-[11px] text-[#A3B8B0]">
                {mode === 'login' ? 'سجل دخولك لمتابعة مشترياتك وطلباتك' : 'تسجيل حساب موحد وسريع في ثوانٍ'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">

          {/* Mode Switcher Tabs */}
          <div className="flex p-1 rounded-2xl bg-[#E6E1D3]/60 border border-[#E6E1D3]">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMessage('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'login'
                  ? 'bg-white text-[#254D3F] shadow-xs'
                  : 'text-[#6B7280] hover:text-[#1F2937]'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMessage('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-white text-[#254D3F] shadow-xs'
                  : 'text-[#6B7280] hover:text-[#1F2937]'
              }`}
            >
              إنشاء حساب جديد
            </button>
          </div>

          {/* Google Sign In Button */}
          <div>
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-2xl bg-white hover:bg-[#F9F8F5] border border-[#D5CEBD] text-[#1F2937] text-xs font-bold transition-all shadow-xs hover:border-[#254D3F] cursor-pointer"
            >
              {/* Google G SVG */}
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>المتابعة بنقرة واحدة باستخدام Google</span>
            </button>

            <div className="relative my-4 flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#E6E1D3]" />
              </div>
              <span className="relative bg-[#F6F4ED] px-3 text-[11px] text-[#6B7280]">
                أو بالبريد وكلمة المرور
              </span>
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Standard Form */}
          <form onSubmit={handleSubmit} className="space-y-3.5">
            
            {/* Name (Register only) */}
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-bold text-[#4B5563] mb-1">
                  الاسم بالكامل *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: أحمد محمود"
                    className="w-full pr-9 pl-3 py-2 rounded-xl bg-white border border-[#E6E1D3] text-xs text-[#1F2937] focus:outline-none focus:border-[#254D3F]"
                    required
                  />
                </div>
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-xs font-bold text-[#4B5563] mb-1">
                البريد الإلكتروني *
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pr-9 pl-3 py-2 rounded-xl bg-white border border-[#E6E1D3] text-xs text-[#1F2937] focus:outline-none focus:border-[#254D3F]"
                  required
                />
              </div>
            </div>

            {/* Phone (Register only) */}
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-bold text-[#4B5563] mb-1">
                  رقم الموبايل (خاص بشركة الشحن لتوصيل الطلبات فقط)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01012345678"
                    dir="ltr"
                    className="w-full pr-9 pl-3 py-2 rounded-xl bg-white border border-[#E6E1D3] text-xs text-[#1F2937] focus:outline-none focus:border-[#254D3F] text-right"
                  />
                </div>
                <p className="text-[10px] text-[#6B7280] mt-1">
                  * رقمك مشفر ومحمي، ولا يظهر للورش؛ تتولى شركة الشحن والمنصة فقط التوصيل.
                </p>
              </div>
            )}

            {/* Governorate (Register only) */}
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-bold text-[#4B5563] mb-1">
                  المحافظة
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <select
                    value={governorate}
                    onChange={(e) => setGovernorate(e.target.value)}
                    className="w-full pr-9 pl-3 py-2 rounded-xl bg-white border border-[#E6E1D3] text-xs text-[#1F2937] focus:outline-none focus:border-[#254D3F]"
                  >
                    {EGYPT_GOVERNORATES.map((gov) => (
                      <option key={gov} value={gov}>{gov}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-[#4B5563]">
                  كلمة المرور *
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => alert('يمكنك تسجيل الدخول السريع عبر Google بنقرة واحدة بدون كلمة مرور')}
                    className="text-[11px] text-[#C97A57] hover:underline cursor-pointer"
                  >
                    نسيت كلمة المرور؟
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-9 pl-9 py-2 rounded-xl bg-white border border-[#E6E1D3] text-xs text-[#1F2937] focus:outline-none focus:border-[#254D3F]"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer mt-3 bg-[#254D3F] hover:bg-[#1A372D]"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>
                    {mode === 'login' ? 'تسجيل الدخول' : 'إنشاء الحساب'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Login Footer */}
          <div className="pt-3 border-t border-[#E6E1D3]/80">
            <button
              type="button"
              onClick={handleQuickDemoLogin}
              className="w-full py-2 px-3 rounded-xl bg-white border border-[#254D3F]/30 text-[11px] text-[#254D3F] font-bold hover:bg-[#254D3F]/5 transition-all text-center flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-[#254D3F]" />
              <span>دخول تجريبي سريع كمتسوق</span>
            </button>
          </div>

          <div className="flex items-center justify-center gap-1.5 text-[10px] text-[#6B7280]">
            <ShieldCheck className="w-3.5 h-3.5 text-[#254D3F]" />
            <span>بياناتك مشفرة ومحمية في منصة يدوي</span>
          </div>

        </div>

      </div>
    </div>
  );
};
